/** Stable render failure categories shared across the Node worker and native helper transports. */
/** Categories a conversion can report across the worker and native helper messages. */
export type ConversionErrorCode = 'input-too-large' | 'output-too-large' | 'invalid-document' | 'unsupported-format' | 'invalid-output' | 'timeout' | 'unavailable' | 'failed';
/** An actionable converter failure; operating-system errors and caller abort reasons remain unchanged. */
export declare class ConversionError extends Error {
    /** Published failure category carried across worker and helper transports. */
    readonly code: ConversionErrorCode;
    /**
     * @param code - Published failure category.
     * @param message - Consumer-facing failure description.
     * @param options - Standard error options; a cause is preserved for diagnostics.
     */
    constructor(code: ConversionErrorCode, message: string, options?: ErrorOptions);
}
/**
 * Only published categories cross worker/helper messages; unknown errors use the generic failure category.
 * @param error - The thrown value, which may be any type and may carry an unpublished `code`.
 * @returns The published category, or `failed` when no published category is present.
 */
export declare function failureCode(error: unknown): ConversionErrorCode;
//# sourceMappingURL=errors.d.ts.map