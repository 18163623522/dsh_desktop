/** Localized search names from LibreOffice Core's fixed font-name dictionary. */
export declare const LOCALIZED_FONT_SEARCH_NAMES: Map<string, string>;
//# sourceMappingURL=native-font-names.d.ts.map