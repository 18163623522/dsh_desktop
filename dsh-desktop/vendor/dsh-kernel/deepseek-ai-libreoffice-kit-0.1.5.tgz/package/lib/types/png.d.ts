export declare function encodePng(width: number, height: number, rgba: Uint8Array | Uint8ClampedArray): Uint8Array;
//# sourceMappingURL=png.d.ts.map